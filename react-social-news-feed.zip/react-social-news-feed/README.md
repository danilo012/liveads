# React social news feed

A Pen created on CodePen.io. Original URL: [https://codepen.io/danilo012/pen/PoxxvrQ](https://codepen.io/danilo012/pen/PoxxvrQ).

Concept of dynamic social news feed with using React JS